package com.police.report;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

import com.police.report.fragment.CrimeFragment;

public class MainActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Fragment crimeFragment = new CrimeFragment();
        commitFragment(crimeFragment, R.id.fragment_container);
    }

    private void commitFragment (Fragment fragment, int fragmentContainer){
        FragmentManager fm = getSupportFragmentManager();
        if (fragment != null){
            fm.beginTransaction().add(fragmentContainer, fragment).commit();
        }
    }
}